Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=97", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("SID=Gwi_StrXOnrWSCbPlprBQleGnCVes93H35Z5uR2W470Kbaw4mB5zpSrB45_FMCjujo7xfg.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSID=Gwi_StrXOnrWSCbPlprBQleGnCVes93H35Z5uR2W470Kbaw4r_ckCtVXUBwnfitZTQA76g.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSID=Gwi_StrXOnrWSCbPlprBQleGnCVes93H35Z5uR2W470Kbaw4AZKFcahnD7IMuvS7drbMUA.; DOMAIN=accounts.google.com");

	web_add_cookie("LSID=o.chat.google.com|o.mail.google.com|s.NO|s.youtube:Gwi_ShPayWpihUIQyQgxfxnc4Ij7b0exBEkmcSAHJ_w8FB1sapWr2TS_CBOmR9J-DIVGvg.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-1PLSID=o.chat.google.com|o.mail.google.com|s.NO|s.youtube:Gwi_ShPayWpihUIQyQgxfxnc4Ij7b0exBEkmcSAHJ_w8FB1sClcj3psV2IkpWu0SpmZ3OQ.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-3PLSID=o.chat.google.com|o.mail.google.com|s.NO|s.youtube:Gwi_ShPayWpihUIQyQgxfxnc4Ij7b0exBEkmcSAHJ_w8FB1sRGU4Ds8YcT__aXpkwdACeg.; DOMAIN=accounts.google.com");

	web_add_cookie("HSID=AoNG-tMg8-W1d2r93; DOMAIN=accounts.google.com");

	web_add_cookie("SSID=AejX5GrZ4fe2Y4v2p; DOMAIN=accounts.google.com");

	web_add_cookie("APISID=r2Og5dr0T88vVLMl/Aoif8wGI8NsNO9tPx; DOMAIN=accounts.google.com");

	web_add_cookie("SAPISID=x0wt18S59pZswuz2/A3n9kgtu4Q-MFYHHV; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PAPISID=x0wt18S59pZswuz2/A3n9kgtu4Q-MFYHHV; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PAPISID=x0wt18S59pZswuz2/A3n9kgtu4Q-MFYHHV; DOMAIN=accounts.google.com");

	web_add_cookie("ACCOUNT_CHOOSER=AFx_qI6Y43C2Oo_7WzEXYh7ZhwlOFVPBLe942m7gf37PjONDNA4twq8Ty4oTU4MtgHI7WZzEhlwi9m1qWIYcj8lJut8BvKxtx7_rkL4COYripeL75Au9mlFQV5Eie_t93z74K79xbKGg9Twn9GaUFQ7b2ewaMPJdq_1tmldAJ8fmagSm_PCerHquANt2yitjPS73ZP31nH0lWmnPX7FzazP6vqDm3mUNSQ; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-GAPS=1:6y-H-NGMEX1Ngvanl4we--bhh6h5xcdLsBiCs2Q7oZSeOaVsAXOS9v0B6aslsygWqaEgduiSH1xPWve5kG6Eq2Uv50k6Lw:gMymXkOgGfOK-kyV; DOMAIN=accounts.google.com");

	web_add_cookie("NID=511=u-eKlpUNoP3SW7niU0tRaipAenKh7Y9Vvest3uCiMOWVzpxLYnHt7A5jMbi7K1NBOs1YJ9s8tBOnNLt_KxaEOyeTvN7khXsyFqN9lea1F9cC4LRP9nxUcxC2b1Nt0OwUXCmXI5Dm4GIzfch2rSM20O81aWhXMeVIuoUrtI_0UH2C-Faqq9Sk94ICe_UQb6JgXRJeiUxk2t4qXGPCq8F2uNls0jtXVcR5i27Ca0HBq02md6M8XltW3S68LxLZq3FkV_-XeVEF6dDVp2oYqTgyKkXEy4ayM1OuIFkNn5kZA4XiBZLjtTNHTM9_PewUHow_Qs10n3pIGZyQWyo; DOMAIN=accounts.google.com");

	web_add_cookie("SIDCC=AJi4QfHe_ZRMv4w64oqEQsUW2Wt1PyL5QSEbbAoqtPFZlJpp3Rgi23l8uhPJ-1xLCNGjYHR7AA; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSIDCC=AJi4QfHgD7hHGC5W_biL6BTH0RJujhFThtQjEGUWsdYKIJj-O26ayk__E1e7-lCJe-Z_xbuW6xI; DOMAIN=accounts.google.com");

	web_add_header("Origin", 
		"https://www.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	web_add_cookie("csrfToken=3d12g9nkhb7cp6r5pt8cb6d8vja34cd7ui8jddt187pht413goh1; DOMAIN=rewardno.saasm2m.com");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("getAllDomainName.jxp", 
		"URL=https://rewardno.saasm2m.com/getAllDomainName.jxp?partnerUniqueId=5", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_cookie("user=0d71883a-3c0a-0594-06e7-2663bc425193; DOMAIN=www.demoblaze.com");

	web_url("www.demoblaze.com", 
		"URL=https://www.demoblaze.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://chromestore.aternity.com/update/crx?os=win&arch=x64&os_arch=x86_64&nacl_arch=x86-64&prod=chromecrx&prodchannel=&prodversion=97.0.4692.99&lang=en-US&acceptformat=crx3&x=id%3Ddcjplbbbfjpafkmpiaobikmlmfbceafm%26v%3D12.1.4.17%26installsource%3Dnotfromwebstore%26installedby%3Dpolicy%26uc", "Referer=", ENDITEM, 
		"Url=/css/fonts/Lato-Regular.woff2", "Referer=https://www.demoblaze.com/css/latofonts.css", ENDITEM, 
		"Url=/imgs/front.jpg", ENDITEM, 
		"Url=https://hls.demoblaze.com/index.m3u8", ENDITEM, 
		"Url=https://hls.demoblaze.com/about_demo_hls_600k.m3u8", ENDITEM, 
		"Url=/imgs/galaxy_s6.jpg", ENDITEM, 
		"Url=/imgs/iphone_6.jpg", ENDITEM, 
		"Url=/imgs/Lumia_1520.jpg", ENDITEM, 
		"Url=/imgs/Nexus_6.jpg", ENDITEM, 
		"Url=/imgs/xperia_z5.jpg", ENDITEM, 
		"Url=/imgs/HTC_M9.jpg", ENDITEM, 
		"Url=/imgs/sony_vaio_5.jpg", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("config.json", 
		"URL=https://www.demoblaze.com/config.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChNDaHJvbWUvOTcuMC40NjkyLjk5Eh4JHPnZyVDpnmQSBQ1ZSoMiEgUNHHpOqRIFDeanSuQSFwmLOdRo7KyeOxIFDTZHxXISBQ0zEFmmEhcJxvlVs6rftUkSBQ2IsVWPEgUNxNLJPA==?alt=proto", "Referer=", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_add_header("Origin", 
		"https://www.demoblaze.com");

	web_url("entries", 
		"URL=https://api.demoblaze.com/entries", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("Demo_2_CreateAccount");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_header("X-Goog-Update-AppId", 
		"ihnlcenocehgdaegdmhbidjhnhdchfmm,oimompecagnajdejgnnjijobebaeigek,hnimpnehoodheedghdeeijklkeaacbdc,gcmjkmgdlgnkkcocmoeiminaijmmjnii,cmahhnpholdijhjokonmfdjbfmklppij,obedbbhbpmojnkanicioggnmelmoomoc,lmelglejhemejginpboagddgdfbepgmp,kiabhabjdbkjdpjbpigfodbdjmbglcoo,gonpemdgkjcecdgbnaabipppbmgfggbe,giekcmmlnklenlaomppkphknjmnnpneh,khaoiebndkojlmppeemjhbpbandiljpe,hfnkpimlhhgieaddgfemjhofmfblmnib,llkgjffcdpffmhiakmfcdcblohccpfmo,laoigpblnllgcgjnjnllmfolckpjlhki,gkmgaooipdjhmangpemjhigmamcehddo,"
		"ehgidpndbllacpjalkiimkbadgjfnnmc,efniojlnjndmcbiieegkicadnoecjjef,jflookgnkcckhobaglndicnbbgbonegd,ggkkehgbnfjpeggfpleeakpidbkibbmn,jamhcnnkihinmdlkakkaopbjbbcngflc,dhlpobdgcjafebgbbhjdnapejmpkgiie,pdafiollngonhoadbmdoemagnfpdphbe,ojhpjlocmbogdgmfpkhlaaeamibhnphh,imefjhfbkmcmebodilednhmaccmincoa,eeigpngbgcognadeebkilcpcaedhellh");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chrome-97.0.4692.99");

	lr_think_time(52);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=11:62sma41ksumrG6IT1RerazozChEmMatPuT11Dg77qwo&cup2hreq=8dd6bf457e0fc4a332700c9a411bbb3b202434881832f6ddc27be1291334152c", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{5fec2575-2da1-40de-bc9f-2dc0b7bb2e90}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{19b575ac-d09c-4a24-a44f-322afdb63e35}\","
		"\"rd\":5510},\"updatecheck\":{},\"version\":\"4.10.2391.0\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6f6bc93dcd62dc251850d2ff458fda96083ceb7fbe8eeb11248b8485ef2aea23\"}]},\"ping\":{\"ping_freshness\":\"{16693215-5aac-4d1d-88aa-85bc6af62007}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GCEA\",\"cohort\":\"1:bm1"
		":11vf@0.01\",\"cohorthint\":\"M54AndUp\",\"cohortname\":\"M54AndUp\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.dbbba5869c1d8946e5e23215c0404619fe82793d60eb89489b345ef55023e077\"}]},\"ping\":{\"ping_freshness\":\"{23de677b-29b4-4334-9dd7-be404fa40f4e}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"9.32.0\"},{\"appid\":\"cmahhnpholdijhjokonmfdjbfmklppij\",\"brand\":\"GCEA\",\"cohort\":\"1:wr3:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\""
		":[{\"fp\":\"1.b4ddbdce4f8d5c080328aa34c19cb533f2eedec580b5d97dc14f74935e4756b7\"}]},\"ping\":{\"ping_freshness\":\"{735c6bdc-d707-47c3-98c0-d110eed5837c}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"1.0.6\"},{\"accept_locale\":\"ENUS500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GCEA\",\"cohort\":\"1:s6f:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.09bcae4d8761ec4a7e8aa090f2f81bd40a3551922a62e2d695bb3faa18477646"
		"\"}]},\"ping\":{\"ping_freshness\":\"{55247180-a895-45a7-aa42-a27284545a03}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"20220112.419803486\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GCEA\",\"cohort\":\"1:lwl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.505f86d2b495a009fe715fcddf55d6af35f5189b4a8b093c7933de0e18595e78\"}]},\"ping\":{\"ping_freshness\":\"{d3f3a90d-3b7c-48c9-a474-e951812f7ed6}\",\"rd\":5510},\""
		"updatecheck\":{},\"version\":\"316\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"GCEA\",\"cohort\":\"1:v3l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.7de0c5b45b564f8089dbeba4a1b4bf821aaa9d946edfc5e98a1baaaef89932f7\"}]},\"ping\":{\"ping_freshness\":\"{1390b281-0014-41e3-9477-11858188d380}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"2022.1.31.1\"},{\"_internal_experimental_sets\":\"false\",\"appid\":\""
		"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GCEA\",\"cohort\":\"1:z1x:\",\"cohorthint\":\"General release\",\"cohortname\":\"General release\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.9f3dda168dccf79be5e9593992108a31d2f83c8fe5f63bfc0a1b725f2a3ca47a\"}]},\"ping\":{\"ping_freshness\":\"{723776c6-3300-4ca7-afd7-84b98cecaad5}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"2021.6.24.0\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GCEA\",\"cohort\":\"1:j5l:\",\""
		"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{24d55949-9ace-40a3-a9e6-5d12814bf5ad}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GCEA\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.d237485db9493e87035e3295dbaa1e24b727c7fb91b24401814fd88f2ab81c3c\"}]},\"ping\":{\"ping_freshness\":\"{6c5e866d-9996-4ce0-b808-5708415e44f7}\",\"rd\":5510},\"tag\":\"46\",\"updatecheck\":{},\"version\":\"47\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GCEA\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.85c39ee10cd7b50ae0834a27bed81cf747eaf0d1658009a43b2feb73a6bf56f5\"}]},\"ping\":{\"ping_freshness\""
		":\"{4caea5a6-7bca-4d8d-9f76-96d22d637507}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"7133\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.689abdc0dc8e916dc8466bf42bfde5635dbe40e64e8d0a86b48008f317cf848b\"}]},\"ping\":{\"ping_freshness\":\"{b9b233cb-7863-425f-8a33-ff4fcfae6c7e}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"1.0.0.10\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\""
		"GCEA\",\"cohort\":\"1:10zr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.db60fc5d4ab81e28fe58d82f3ad26622c4ca4cade28e2b636068ac91ca62224d\"}]},\"ping\":{\"ping_freshness\":\"{8c6f3ac2-5fbe-4e37-a459-a61cf5a88563}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"1.0.7.1642025427\"},{\"appid\":\"gkmgaooipdjhmangpemjhigmamcehddo\",\"brand\":\"GCEA\",\"cohort\":\"1:pw3:\",\"cohorthint\":\"Stable\",\"cohortname\":\"Stable\",\"enabled\":true,\""
		"packages\":{\"package\":[{\"fp\":\"1.9a4393fa2f5a5a43e21ab7365ea12c87ae7be963d6fbcf49abd499ebd7d50b65\"}]},\"ping\":{\"ping_freshness\":\"{f6f65b30-040d-4698-8bfa-38773b3de878}\",\"rd\":5510},\"tag\":\"eset_exp_b\",\"updatecheck\":{},\"version\":\"96.276.200\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GCEA\",\"cohort\":\"1:ofl:\",\"cohorthint\":\"stable64\",\"cohortname\":\"stable64\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{8f0fd89e-e50f-43b9-a7fb-5e509971775d}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GCEA\",\"cohort\":\"1:zkl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.4fd359c9d2c0f81e54caa538477b63cf8c5f86e267f7218ff5c57440bfe876bf\"}]},\"ping\":{\"ping_freshness\":\""
		"{97bcf744-1a95-4e45-90d3-b185fb285295}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"157\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GCEA\",\"cohort\":\"1:s7x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.ffcda540f242b9ba326823a75de28cd80343fe31a38285db4264081547265fc0\"}]},\"ping\":{\"ping_freshness\":\"{718ace2b-5313-4336-bc92-e8d62734ebcb}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"2770\"},{\"appid\":\""
		"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GCEA\",\"cohort\":\"1:ut9:\",\"cohorthint\":\"M80ToM99\",\"cohortname\":\"M80ToM99\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.f01d0cf1209718138dc6596dff43a8c55e847414baac537edc5f9f23f8fa62b6\"}]},\"ping\":{\"ping_freshness\":\"{c86956c2-a134-4ab9-aeda-4f91d3efcf7e}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"2022.1.24.1201\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GCEA\",\"cohort\":\"1:wvr:\",\"cohorthint\":\""
		"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.31365eb4f3fbb1593ddc7f89ae65d4abcbc6c8f10e0d4b6f02d0136d5fd9a2ca\"}]},\"ping\":{\"ping_freshness\":\"{f4badc4e-f9b6-4aaa-8cd7-440538b0d3f4}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"100.0.4863.0\"},{\"appid\":\"dhlpobdgcjafebgbbhjdnapejmpkgiie\",\"brand\":\"GCEA\",\"cohort\":\"1:z9x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.8b9dc2cd32d1b5f147a17377cef75ec160103d6c02faf4947978fb6d9a25983b\"}]},\"ping\":{\"ping_freshness\":\"{c56f0c43-16f1-4a4c-bf0f-e6865c254d9c}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"20211020.1\"},{\"appid\":\"pdafiollngonhoadbmdoemagnfpdphbe\",\"brand\":\"GCEA\",\"cohort\":\"1:vz3:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.54b93e249d02a0f9061e8f70866d4668a0260db9ae43483810ab78f97f3eaa2a\"}]},\"ping\":{\"ping_freshness\":\""
		"{b2a6639a-3786-4096-9217-17e6356e1337}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"2021.8.17.1300\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GCEA\",\"cohort\":\"1:w0x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.478aa915e78878e332a0b4bb4d2a6fb67ff1c7f7b62fe906f47095ba5ae112d0\"}]},\"ping\":{\"ping_freshness\":\"{f70751f3-529a-4348-bf9d-ac94a30e9665}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"1\"},{\"appid\""
		":\"imefjhfbkmcmebodilednhmaccmincoa\",\"brand\":\"GCEA\",\"cohort\":\"1:zor:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.90d6e329a99396aced52c13595b29a8af1e2711cdd6f73008ae51d0be83356be\"}]},\"ping\":{\"ping_freshness\":\"{cbdc4424-16d5-48b1-8211-2bdb36c090ea}\",\"rd\":5510},\"tag\":\"default\",\"updatecheck\":{},\"version\":\"27.5\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GCEA\",\"cohort\":\"1:w59:\",\"cohorthint\""
		":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{639c1beb-2803-4d16-adf8-f5011b907c40}\",\"rd\":5510},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"physmemory\":32},\"ismachine\":true,\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\""
		"version\":\"10.0.19044.1466\"},\"prodversion\":\"97.0.4692.99\",\"protocol\":\"3.1\",\"requestid\":\"{e7e5ba4e-078a-40a8-9c3c-c93f641b9ccc}\",\"sessionid\":\"{94371759-ae0e-4d9c-bd64-17b4989a0de1}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.36.122\"},\"updaterversion\":\"97.0.4692.99\"}}", 
		LAST);

	/* Click on Sign up */

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://www.demoblaze.com");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	lr_think_time(40);

	web_custom_request("signup", 
		"URL=https://api.demoblaze.com/signup", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("signup_2", 
		"URL=https://api.demoblaze.com/signup", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"username\":\"itera123\",\"password\":\"aXRlcmExMjM=\"}", 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates_fetch?$req="
		"ChwKDGdvb2dsZWNocm9tZRIMOTcuMC40NjkyLjk5GikIBRABGhsKDQgFEAYYASIDMDAxMAEQvrANGgIYBlrmDxkiBCABIAIoARopCAEQARobCg0IARAGGAEiAzAwMTABEIGfChoCGAZU3poAIgQgASACKAEaKQgHEAEaGwoNCAcQBhgBIgMwMDEwARCV0woaAhgGJv8pzSIEIAEgAigBGicIARABGhkKDQgBEAYYASIDMDAxMAMQFBoCGAb7ks9FIgQgASACKAMaKAgBEAgaGgoNCAEQCBgBIgMwMDEwBBCeJhoCGAYdVn0-IgQgASACKAQaKAgPEAEaGgoNCA8QBhgBIgMwMDEwARD0cBoCGAaQ3NNIIgQgASACKAEaJwgKEAgaGQoNCAoQCBgBIgMwMDEwARAHGgIYBvdxNsIiBCABIAIoARonCAkQARoZCg0ICRAGGAEiAzAwMTABECAaAhgGnzCSwSIEIAEgAigBGigICBABGhoKDQ"
		"gIEAYYASIDMDAxMAEQvg4aAhgGv59xaCIEIAEgAigBGikIDRABGhsKDQgNEAYYASIDMDAxMAEQl68BGgIYBt9k9hwiBCABIAIoARopCAMQARobCg0IAxAGGAEiAzAwMTABENzdCRoCGAapP3P9IgQgASACKAEaKQgOEAEaGwoNCA4QBhgBIgMwMDEwARCjoAYaAhgGzma0yCIEIAEgAigBGigIEBABGhoKDQgQEAYYASIDMDAxMAEQgRAaAhgGe8-XryIEIAEgAigBIgIIAQ==&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	lr_start_transaction("Demo_3_Login");

	/* Click on Login & enter your credentials */

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	lr_think_time(12);

	web_custom_request("login", 
		"URL=https://api.demoblaze.com/login", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("login_2", 
		"URL=https://api.demoblaze.com/login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"username\":\"itera123\",\"password\":\"aXRlcmExMjM=\"}", 
		LAST);

	web_add_cookie("tokenp_=aXRlcmExMjMxNjQ0MzEz; DOMAIN=www.demoblaze.com");

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("www.demoblaze.com_2", 
		"URL=https://www.demoblaze.com/", 
		"Resource=0", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/node_modules/bootstrap/dist/css/bootstrap.min.css", ENDITEM, 
		"Url=/css/latofonts.css", ENDITEM, 
		"Url=/node_modules/video.js/dist/video-js.min.css", ENDITEM, 
		"Url=/css/latostyle.css", ENDITEM, 
		"Url=/node_modules/jquery/dist/jquery.min.js", ENDITEM, 
		"Url=/node_modules/video.js/dist/video.min.js", ENDITEM, 
		"Url=/node_modules/videojs-contrib-hls/dist/videojs-contrib-hls.min.js", ENDITEM, 
		"Url=/node_modules/bootstrap/dist/js/bootstrap.min.js", ENDITEM, 
		"Url=/js/index.js", ENDITEM, 
		"Url=/imgs/front.jpg", ENDITEM, 
		"Url=/node_modules/tether/dist/js/tether.min.js", ENDITEM, 
		"Url=/bm.png", ENDITEM, 
		"Url=/Samsung1.jpg", ENDITEM, 
		"Url=/nexus1.jpg", ENDITEM, 
		"Url=/iphone1.jpg", ENDITEM, 
		"Url=/config.json", ENDITEM, 
		"Url=/favicon.ico", ENDITEM, 
		"Url=/imgs/galaxy_s6.jpg", ENDITEM, 
		"Url=/imgs/Lumia_1520.jpg", ENDITEM, 
		"Url=/imgs/Nexus_6.jpg", ENDITEM, 
		"Url=/imgs/iphone_6.jpg", ENDITEM, 
		"Url=/imgs/HTC_M9.jpg", ENDITEM, 
		"Url=/imgs/xperia_z5.jpg", ENDITEM, 
		"Url=/imgs/sony_vaio_5.jpg", ENDITEM, 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://www.demoblaze.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_custom_request("check", 
		"URL=https://api.demoblaze.com/check", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("check_2", 
		"URL=https://api.demoblaze.com/check", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"token\":\"aXRlcmExMjMxNjQ0MzEz\"}", 
		LAST);

	web_url("entries_2", 
		"URL=https://api.demoblaze.com/entries", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("Demo_4_addItem");

	/* Add items to cart */

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(79);

	web_url("prod.html", 
		"URL=https://www.demoblaze.com/prod.html?idp_=2", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/imgs/front.jpg", "Referer=https://www.demoblaze.com/prod.html?idp_=2", ENDITEM, 
		"Url=/css/fonts/Lato-Regular.woff2", "Referer=https://www.demoblaze.com/css/latofonts.css", ENDITEM, 
		"Url=/config.json", "Referer=https://www.demoblaze.com/prod.html?idp_=2", ENDITEM, 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_auto_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_auto_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://www.demoblaze.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_custom_request("check_3", 
		"URL=https://api.demoblaze.com/check", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("view", 
		"URL=https://api.demoblaze.com/view", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Access-Control-Request-Headers");

	web_revert_auto_header("Access-Control-Request-Method");

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("view_2", 
		"URL=https://api.demoblaze.com/view", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":\"2\"}", 
		LAST);

	web_custom_request("check_4", 
		"URL=https://api.demoblaze.com/check", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"token\":\"aXRlcmExMjMxNjQ0MzEz\"}", 
		EXTRARES, 
		"Url=https://www.demoblaze.com/imgs/Lumia_1520.jpg", "Referer=https://www.demoblaze.com/prod.html?idp_=2", ENDITEM, 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_custom_request("addtocart", 
		"URL=https://api.demoblaze.com/addtocart", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("addtocart_2", 
		"URL=https://api.demoblaze.com/addtocart", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":\"81451d8b-96e7-7199-105e-68282189c559\",\"cookie\":\"aXRlcmExMjMxNjQ0MzEz\",\"prod_id\":2,\"flag\":true}", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(7);

	web_url("index.html", 
		"URL=https://www.demoblaze.com/index.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/prod.html?idp_=2", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/imgs/front.jpg", ENDITEM, 
		"Url=/css/fonts/Lato-Regular.woff2", "Referer=https://www.demoblaze.com/css/latofonts.css", ENDITEM, 
		"Url=/config.json", ENDITEM, 
		"Url=/imgs/Lumia_1520.jpg", ENDITEM, 
		"Url=/imgs/galaxy_s6.jpg", ENDITEM, 
		"Url=/imgs/Nexus_6.jpg", ENDITEM, 
		"Url=/imgs/xperia_z5.jpg", ENDITEM, 
		"Url=/imgs/iphone_6.jpg", ENDITEM, 
		"Url=/imgs/HTC_M9.jpg", ENDITEM, 
		"Url=/imgs/sony_vaio_5.jpg", ENDITEM, 
		"Url=/imgs/dell.jpg", ENDITEM, 
		"Url=/imgs/macbook_air.jpg", ENDITEM, 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://www.demoblaze.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_custom_request("check_5", 
		"URL=https://api.demoblaze.com/check", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("entries_3", 
		"URL=https://api.demoblaze.com/entries", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("check_6", 
		"URL=https://api.demoblaze.com/check", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"token\":\"aXRlcmExMjMxNjQ0MzEz\"}", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	lr_think_time(4);

	web_custom_request("bycat", 
		"URL=https://api.demoblaze.com/bycat", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("bycat_2", 
		"URL=https://api.demoblaze.com/bycat", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"cat\":\"notebook\"}", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("prod.html_2", 
		"URL=https://www.demoblaze.com/prod.html?idp_=9", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/index.html", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_auto_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_auto_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://www.demoblaze.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_custom_request("check_7", 
		"URL=https://api.demoblaze.com/check", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("view_3", 
		"URL=https://api.demoblaze.com/view", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Access-Control-Request-Headers");

	web_revert_auto_header("Access-Control-Request-Method");

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("check_8", 
		"URL=https://api.demoblaze.com/check", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"token\":\"aXRlcmExMjMxNjQ0MzEz\"}", 
		LAST);

	web_custom_request("view_4", 
		"URL=https://api.demoblaze.com/view", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":\"9\"}", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_custom_request("addtocart_3", 
		"URL=https://api.demoblaze.com/addtocart", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("addtocart_4", 
		"URL=https://api.demoblaze.com/addtocart", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":\"dbb3bee7-2de1-ebc3-bd1c-771c63881245\",\"cookie\":\"aXRlcmExMjMxNjQ0MzEz\",\"prod_id\":9,\"flag\":true}", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(4);

	web_url("index.html_2", 
		"URL=https://www.demoblaze.com/index.html", 
		"Resource=0", 
		"Referer=https://www.demoblaze.com/prod.html?idp_=9", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/node_modules/bootstrap/dist/css/bootstrap.min.css", ENDITEM, 
		"Url=/css/latofonts.css", ENDITEM, 
		"Url=/css/latostyle.css", ENDITEM, 
		"Url=/node_modules/video.js/dist/video-js.min.css", ENDITEM, 
		"Url=/node_modules/jquery/dist/jquery.min.js", ENDITEM, 
		"Url=/node_modules/video.js/dist/video.min.js", ENDITEM, 
		"Url=/node_modules/videojs-contrib-hls/dist/videojs-contrib-hls.min.js", ENDITEM, 
		"Url=/node_modules/tether/dist/js/tether.min.js", ENDITEM, 
		"Url=/node_modules/bootstrap/dist/js/bootstrap.min.js", ENDITEM, 
		"Url=/js/index.js", ENDITEM, 
		"Url=/Samsung1.jpg", ENDITEM, 
		"Url=/bm.png", ENDITEM, 
		"Url=/imgs/front.jpg", ENDITEM, 
		"Url=/nexus1.jpg", ENDITEM, 
		"Url=/iphone1.jpg", ENDITEM, 
		"Url=/config.json", ENDITEM, 
		"Url=/favicon.ico", ENDITEM, 
		"Url=/imgs/sony_vaio_5.jpg", ENDITEM, 
		"Url=/imgs/galaxy_s6.jpg", ENDITEM, 
		"Url=/imgs/Lumia_1520.jpg", ENDITEM, 
		"Url=/imgs/Nexus_6.jpg", ENDITEM, 
		"Url=/imgs/iphone_6.jpg", ENDITEM, 
		"Url=/imgs/xperia_z5.jpg", ENDITEM, 
		"Url=/imgs/HTC_M9.jpg", ENDITEM, 
		"Url=/imgs/asusm.jpg", ENDITEM, 
		"Url=/imgs/apple_cinema.jpg", ENDITEM, 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://www.demoblaze.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_custom_request("check_9", 
		"URL=https://api.demoblaze.com/check", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("entries_4", 
		"URL=https://api.demoblaze.com/entries", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("check_10", 
		"URL=https://api.demoblaze.com/check", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"token\":\"aXRlcmExMjMxNjQ0MzEz\"}", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_custom_request("bycat_3", 
		"URL=https://api.demoblaze.com/bycat", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("bycat_4", 
		"URL=https://api.demoblaze.com/bycat", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"cat\":\"monitor\"}", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("prod.html_3", 
		"URL=https://www.demoblaze.com/prod.html?idp_=10", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/index.html", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://www.demoblaze.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_custom_request("view_5", 
		"URL=https://api.demoblaze.com/view", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t48.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("check_11", 
		"URL=https://api.demoblaze.com/check", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t49.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"token\":\"aXRlcmExMjMxNjQ0MzEz\"}", 
		LAST);

	web_custom_request("view_6", 
		"URL=https://api.demoblaze.com/view", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t50.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":\"10\"}", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_custom_request("addtocart_5", 
		"URL=https://api.demoblaze.com/addtocart", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t51.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("addtocart_6", 
		"URL=https://api.demoblaze.com/addtocart", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t52.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":\"21b0f09c-c640-79ce-b498-e29dee4c25dd\",\"cookie\":\"aXRlcmExMjMxNjQ0MzEz\",\"prod_id\":10,\"flag\":true}", 
		LAST);

	lr_end_transaction("Demo_4_addItem",LR_AUTO);

	lr_start_transaction("Demo_5_checkout");

	/* Click on cart. Fill details & checkout */

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(52);

	web_url("cart.html", 
		"URL=https://www.demoblaze.com/cart.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/prod.html?idp_=10", 
		"Snapshot=t53.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/css/fonts/Lato-Regular.woff2", "Referer=https://www.demoblaze.com/css/latofonts.css", ENDITEM, 
		"Url=/imgs/front.jpg", ENDITEM, 
		"Url=/config.json", ENDITEM, 
		"Url=/imgs/sony_vaio_5.jpg", ENDITEM, 
		"Url=/imgs/Lumia_1520.jpg", ENDITEM, 
		"Url=/imgs/apple_cinema.jpg", ENDITEM, 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_auto_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_auto_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://www.demoblaze.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_custom_request("check_12", 
		"URL=https://api.demoblaze.com/check", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t54.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("viewcart", 
		"URL=https://api.demoblaze.com/viewcart", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t55.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Access-Control-Request-Headers");

	web_revert_auto_header("Access-Control-Request-Method");

	web_add_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("viewcart_2", 
		"URL=https://api.demoblaze.com/viewcart", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t56.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"cookie\":\"aXRlcmExMjMxNjQ0MzEz\",\"flag\":true}", 
		LAST);

	web_add_auto_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_auto_header("Access-Control-Request-Method", 
		"POST");

	web_custom_request("view_7", 
		"URL=https://api.demoblaze.com/view", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t57.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("view_8", 
		"URL=https://api.demoblaze.com/view", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t58.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("view_9", 
		"URL=https://api.demoblaze.com/view", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t59.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Access-Control-Request-Headers");

	web_revert_auto_header("Access-Control-Request-Method");

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("check_13", 
		"URL=https://api.demoblaze.com/check", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t60.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"token\":\"aXRlcmExMjMxNjQ0MzEz\"}", 
		LAST);

	web_custom_request("view_10", 
		"URL=https://api.demoblaze.com/view", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t61.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":9}", 
		LAST);

	web_custom_request("view_11", 
		"URL=https://api.demoblaze.com/view", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t62.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":2}", 
		LAST);

	web_custom_request("view_12", 
		"URL=https://api.demoblaze.com/view", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t63.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":10}", 
		LAST);

	lr_end_transaction("Demo_5_checkout",LR_AUTO);

	lr_start_transaction("Demo_6_PlaceOrder");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	lr_think_time(83);

	web_custom_request("deletecart", 
		"URL=https://api.demoblaze.com/deletecart", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t64.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("deletecart_2", 
		"URL=https://api.demoblaze.com/deletecart", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t65.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"cookie\":\"itera123\"}", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("index.html_3", 
		"URL=https://www.demoblaze.com/index.html", 
		"Resource=0", 
		"Referer=https://www.demoblaze.com/cart.html", 
		"Snapshot=t66.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/node_modules/bootstrap/dist/css/bootstrap.min.css", ENDITEM, 
		"Url=/node_modules/video.js/dist/video-js.min.css", ENDITEM, 
		"Url=/css/latofonts.css", ENDITEM, 
		"Url=/node_modules/jquery/dist/jquery.min.js", ENDITEM, 
		"Url=/css/latostyle.css", ENDITEM, 
		"Url=/node_modules/video.js/dist/video.min.js", ENDITEM, 
		"Url=/node_modules/videojs-contrib-hls/dist/videojs-contrib-hls.min.js", ENDITEM, 
		"Url=/node_modules/tether/dist/js/tether.min.js", ENDITEM, 
		"Url=/js/index.js", ENDITEM, 
		"Url=/node_modules/bootstrap/dist/js/bootstrap.min.js", ENDITEM, 
		"Url=/bm.png", ENDITEM, 
		"Url=/imgs/front.jpg", ENDITEM, 
		"Url=/Samsung1.jpg", ENDITEM, 
		"Url=/iphone1.jpg", ENDITEM, 
		"Url=/nexus1.jpg", ENDITEM, 
		"Url=/config.json", ENDITEM, 
		"Url=/favicon.ico", ENDITEM, 
		"Url=/imgs/galaxy_s6.jpg", ENDITEM, 
		"Url=/imgs/Lumia_1520.jpg", ENDITEM, 
		"Url=/imgs/iphone_6.jpg", ENDITEM, 
		"Url=/imgs/Nexus_6.jpg", ENDITEM, 
		"Url=/imgs/HTC_M9.jpg", ENDITEM, 
		"Url=/imgs/xperia_z5.jpg", ENDITEM, 
		"Url=/imgs/sony_vaio_5.jpg", ENDITEM, 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://www.demoblaze.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_custom_request("check_14", 
		"URL=https://api.demoblaze.com/check", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t67.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("entries_5", 
		"URL=https://api.demoblaze.com/entries", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t68.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("check_15", 
		"URL=https://api.demoblaze.com/check", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t69.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"token\":\"aXRlcmExMjMxNjQ0MzEz\"}", 
		LAST);

	lr_end_transaction("Demo_6_PlaceOrder",LR_AUTO);

	lr_start_transaction("Demo_7_logout");

	/* click on Logout */

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(24);

	web_url("index.html_4", 
		"URL=https://www.demoblaze.com/index.html", 
		"Resource=0", 
		"Referer=https://www.demoblaze.com/index.html", 
		"Snapshot=t70.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/node_modules/bootstrap/dist/css/bootstrap.min.css", ENDITEM, 
		"Url=/node_modules/video.js/dist/video-js.min.css", ENDITEM, 
		"Url=/css/latofonts.css", ENDITEM, 
		"Url=/css/latostyle.css", ENDITEM, 
		"Url=/node_modules/video.js/dist/video.min.js", ENDITEM, 
		"Url=/node_modules/jquery/dist/jquery.min.js", ENDITEM, 
		"Url=/node_modules/videojs-contrib-hls/dist/videojs-contrib-hls.min.js", ENDITEM, 
		"Url=/node_modules/tether/dist/js/tether.min.js", ENDITEM, 
		"Url=/node_modules/bootstrap/dist/js/bootstrap.min.js", ENDITEM, 
		"Url=/js/index.js", ENDITEM, 
		"Url=/imgs/front.jpg", ENDITEM, 
		"Url=/bm.png", ENDITEM, 
		"Url=/Samsung1.jpg", ENDITEM, 
		"Url=/nexus1.jpg", ENDITEM, 
		"Url=/iphone1.jpg", ENDITEM, 
		"Url=/config.json", ENDITEM, 
		"Url=/favicon.ico", ENDITEM, 
		"Url=/imgs/galaxy_s6.jpg", ENDITEM, 
		"Url=/imgs/Nexus_6.jpg", ENDITEM, 
		"Url=/imgs/Lumia_1520.jpg", ENDITEM, 
		"Url=/imgs/iphone_6.jpg", ENDITEM, 
		"Url=/imgs/HTC_M9.jpg", ENDITEM, 
		"Url=/imgs/xperia_z5.jpg", ENDITEM, 
		"Url=/imgs/sony_vaio_5.jpg", ENDITEM, 
		LAST);

	web_add_header("Origin", 
		"https://www.demoblaze.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_url("entries_6", 
		"URL=https://api.demoblaze.com/entries", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.demoblaze.com/", 
		"Snapshot=t71.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Demo_7_logout",LR_AUTO);

	return 0;
}